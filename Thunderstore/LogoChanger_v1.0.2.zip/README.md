# Description

## Changes main menu logo and mistlands logo. Change change the name it searches for in BepInEx folder. Comes with a default logo & default game logos as examples.

`ONLY WORKS ON Mistlands & later.`

#### Need to Know

- Default names are `LogoChanger_LOGO.png` (1000x394) & `LogoChanger_MistlandsLogo.png` (2048x448)
    - Put the logos anywhere in the BepInEx folder
- Additionally comes with the default logos as examples to use to make your own.

---

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***

> # Update Information (Latest listed first)
> ### v1.0.2
> - Include the original files in the zip. Forgot them in 1.0.1
> ### v1.0.1
> - Fixed a bug where the logo would not change correctly
> ### v1.0.0
> - Initial Release