> ### v1.0.4
> - Fix a bug with how the mod is packaged. Unfortunately this means that I cannot provide the logo images outside of
    the zip like I used to. This is to protect custom images from being overriden should they have the same name as the
    default logos.
> ### v1.0.3
> - Fix a compatibility issue. Thanks to ZenDragon for a report.
> - Moved the default images to the config folder instead of the plugin folder. This will be done automatically. They
    will be moved to the config folder inside of Azumatt.LogoChanger_Images if they meet the requirements. The
    requirements are that the image is prefixed with LogoChanger and is png format.
> ### v1.0.2
> - Include the original files in the zip. Forgot them in 1.0.1
> ### v1.0.1
> - Fixed a bug where the logo would not change correctly
> ### v1.0.0
> - Initial Release